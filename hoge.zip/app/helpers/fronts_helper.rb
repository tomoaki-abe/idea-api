module FrontsHelper
end
