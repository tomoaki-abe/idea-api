class IdeasController < ApplicationController
end
