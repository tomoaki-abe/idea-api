class FrontsController < ApplicationController
  def index
  end
end
